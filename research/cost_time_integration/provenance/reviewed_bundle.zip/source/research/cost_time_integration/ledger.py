"""Independent sequential ledger: no optimizer matrices or project timing calls."""
from decimal import Decimal
from numbers import Real


def audit(c, q):
    def invalid(message):
        return dict(valid=False, errors=[message], ledger=[])
    try:
        q = list(q)
    except TypeError:
        return invalid('quantity vector required')
    n = len(c['leg_demands_t'])
    if n != 4 or len(q) != n:
        return invalid('quantity vector length must equal four legs')
    if any(len(c[key]) != n for key in ('calls', 'arrival_reserves_t', 'supply_max_t',
            'available', 'minimum_lift_t', 'prices_usd_per_t', 'fixed_fee_usd', 'variable_fee_usd_per_t')):
        return invalid('case vector shape')
    for raw in q:
        if isinstance(raw, bool) or not isinstance(raw, (Real, Decimal)):
            return invalid('quantity must be a numeric scalar, not boolean/string')
        value = Decimal(str(raw))
        if not value.is_finite() or value < 0:
            return invalid('quantity must be finite and nonnegative')
    D = lambda x: Decimal(str(x))
    tol = D('1e-7'); time_tol = D('1e-6')
    inv = D(c['initial_inventory_t']); cost = D(0)
    total_time = D(c['sailing_hours'])+D(c['baseline_existing_call_hours'])
    rows, errors = [], []
    if inv < D(c['arrival_reserves_t'][0])-tol:
        errors.append('initial reserve')
    for i, raw in enumerate(q):
        qty = D(raw); positive = qty > 0; call = c['calls'][i]
        before = inv; departure = before+qty; inv = departure-D(c['leg_demands_t'][i])
        if qty < 0 or qty > D(c['supply_max_t'][i])+tol: errors.append(f'{i}:supply')
        if positive and not c['available'][i]: errors.append(f'{i}:availability')
        if positive and qty < D(c['minimum_lift_t'][i])-tol: errors.append(f'{i}:minimum')
        if departure > D(c['capacity_t'])+tol: errors.append(f'{i}:capacity')
        if inv < D(c['arrival_reserves_t'][i])-tol: errors.append(f'{i}:arrival reserve')
        # A zero purchase needs no price. Unavailable ports may have price=None.
        subtotal = D(0)
        delay = D(0)
        if positive:
            if c['prices_usd_per_t'][i] is None:
                return invalid(f'{i}:positive purchase requires a known price')
            subtotal = qty*(D(c['prices_usd_per_t'][i])+D(c['variable_fee_usd_per_t'][i]))
            subtotal += D(c['fixed_fee_usd'][i])
            work = D(call['preparation_hours'])+qty*D(call['transfer_hours_per_t'])+D(call['cleanup_hours'])
            if call['kind'] == 'existing':
                finish = max(D(call['cargo_end_with_bunkering_hours']), D(call['bunker_ready_hours'])+work)
                delay = max(D(call['baseline_departure_hours']), finish+D(call['departure_readiness_hours']))-D(call['baseline_departure_hours'])
            else:
                delay = work+sum(D(call[k+'_hours']) for k in ('detour', 'port_transit', 'waiting'))
        cost += subtotal; total_time += delay
        rows.append(dict(before_t=str(before), q_t=str(qty), departure_t=str(departure), arrival_t=str(inv), cost_usd=str(subtotal), extra_hours=str(delay)))
    if abs(inv-D(c['terminal_inventory_exact_t'])) > tol: errors.append('terminal')
    if total_time > D(c['deadline_hours'])+time_tol: errors.append('deadline')
    return dict(valid=not errors, errors=errors, ledger=rows, cost_usd=float(cost), time_hours=float(total_time), terminal_t=float(inv))
