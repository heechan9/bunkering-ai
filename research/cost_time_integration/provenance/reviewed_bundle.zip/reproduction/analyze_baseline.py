"""Reproduce only completed full-run failures on untouched raw main."""
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import os
import json

root=Path(__file__).parent
tree=ET.parse(root/'full-lf-final.xml')
baseline=root/'clean-main-lf'
nodes=[]
for case in tree.iter('testcase'):
    if case.find('failure') is None and case.find('error') is None: continue
    parts=case.attrib['classname'].split('.')
    for length in range(len(parts),0,-1):
        candidate=Path(*parts[:length]).with_suffix('.py')
        if (baseline/candidate).exists():
            nodes.append(candidate.as_posix()+'::'+'::'.join(parts[length:]+[case.attrib['name']]))
            break
    else: raise RuntimeError(case.attrib)
(root/'baseline_failed_nodes.json').write_text(json.dumps(nodes,indent=2)+'\n')
python=r'C:\Users\hc247\Documents\Codex\2026-10-15\task-2\.venv-procurement\Scripts\python.exe'
cmd=[python,'-m','pytest',*nodes,'-q','--strict-config','--strict-markers','-W','error','--tb=short',
     '--basetemp=../pytest-clean-main-failures','--junitxml=../clean-main-failures.xml']
(root/'baseline_command.json').write_text(json.dumps(dict(command=cmd,cwd=str(baseline)),indent=2)+'\n')
runtime_temp=root/'runtime-temp-baseline'
runtime_temp.mkdir(exist_ok=True)
env={**os.environ,'OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','PYTHONHASHSEED':'0','PYTHONUTF8':'1','MPLBACKEND':'Agg',
     'TEMP':str(runtime_temp),'TMP':str(runtime_temp)}
with (root/'clean-main-failures.log').open('w',encoding='utf-8') as log:
    result=subprocess.run(cmd,cwd=baseline,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
print('clean-main reproduction exit',result.returncode)
print((root/'clean-main-failures.log').read_text(encoding='utf-8')[-5000:])
