from pathlib import Path
import shutil
import subprocess
import zipfile
import hashlib
import json

root=Path(__file__).parent
source=root/'bunkering-cost-time'
target=root/'full-suite-pr126-compat'
if target.exists(): raise FileExistsError(target)
zipfile.ZipFile(root/'main-lf.zip').extractall(target)
for module in ('procurement_baseline','cost_time_integration'):
    shutil.copytree(source/'research'/module,target/'research'/module,ignore=shutil.ignore_patterns('__pycache__'))
for file in ('test_procurement_baseline_core.py','test_procurement_baseline_policies.py'):
    shutil.copy2(source/'tests'/file,target/'tests'/file)
files=['research/fair_replacement_eval/'+name+'.py' for name in
       ('common','test_checkpoint_special_files','test_shadow_timeout')]
manifest={}
for file in files:
    raw=subprocess.check_output(['git','show','57de151d19e54ec58248fd1edfe94fb1af9c6520:'+file],cwd=source)
    (target/file).write_bytes(raw)
    manifest[file]=hashlib.sha256(raw).hexdigest()
subprocess.run(['git','init'],cwd=target,check=True)
(root/'pr126_compat_overlay_hashes.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
