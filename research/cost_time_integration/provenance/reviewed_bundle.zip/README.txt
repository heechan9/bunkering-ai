Review package: synthetic fixed-route cost and incremental call-time research.
Read evidence/final_review_report.txt first. Older phase reports/logs remain historical.
To reconstruct the final tested tree: extract baseline/main-lf.zip into a new directory;
overlay dependencies/ and source/ at that root; then overlay overlays/pr126_windows/.
Initialize a local Git repository there for the check-ignore regression. Use an existing
compatible Python environment and writable TEMP/TMP and pytest basetemp. See exact command
and versions in the final report. No environment installation is part of this package.
The final patch alone requires the procurement dependency from PR126; the Windows overlay
is separately identified, not hidden inside the new integration patch. Reporting tests
from the whole pending PR126 were not imported. All28 frozen cases are now pytest items.
Manifest hashes are raw bytes. Git patches normalize text line endings, so applied-patch
result JSON bytes can differ by CRLF/LF. Input fixtures and their saved hashes are retained.
No credentials, local environment, untracked user assets or new model are packaged.
Library upload identity is supplied after packaging, outside this immutable ZIP.
