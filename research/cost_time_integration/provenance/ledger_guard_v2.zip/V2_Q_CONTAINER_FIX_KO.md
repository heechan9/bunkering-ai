# v2 추가 수정: 구매벡터 컨테이너

Claude 변경분 검토에서 q 자체의 dict/set 우회가 발견됐다. 이전 후보에서 deadline100, q={1:'junk',2:None,3:NaN,10:'x'}는 keys를 구매량으로 읽어 valid=True/cost10100이 됐다. 자체 재현으로 확인했고 q의 Mapping/Set(str/bytes 포함)을 list 변환 전에 거부하도록 최소 guard를 추가했다. dict/set/frozenset/text/bytes와 정상 ordered generator6개 시험 추가.187회귀 PASS, 경계8PASS, 동결28전후동일. 원본·이전후보는 보존했다.

수정은 q입력 검증만 추가하며 reserve/deadline/계산본문·solver는 변경하지 않았다. 새candidate SHA는 PROVENANCE_AND_RESULTS.json 기준이다. 이전 독립검토175+8결과는 이전후보에만 해당하며 새버전 외부검토로 소급하지 않는다. 새 후보에 대해 q컨테이너 우회가 닫혔는지, 정상 ordered입력이 유지되는지만 집중 재검토 요청한다.
