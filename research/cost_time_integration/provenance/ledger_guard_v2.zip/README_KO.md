# 독립 원장 수치 입력 guard: 적용 전 수정 후보

2026-10-16. 별도 클라우드 검증 사본만 수정했다. 원본 ZIP, 사용자 PC, 저장소·배포는 변경하지 않았다.

## 변경 범위

- ledger에 직접 전달되는 case 수치의 허용 타입(Real/Decimal), bool/string 제외, 유한성·비음수 및4개 길이를 확인한다. availability는 bool, call kind는 기존2종만 허용한다.
- Mapping/string/bytes 컨테이너를 벡터로 받지 않으며 검증과 계산이 같은 인덱스 값을 읽는다. 목록·튜플·NumPy 배열을 유지한다.
- None 가격은 비가용 항구에서만 허용한다. 미상 시간은0으로 바꾸지 않고 invalid로 반환한다. 사용하지 않는 기항도 검증하므로 direct audit가 이전에 허용하던 일부 미상값은 거부된다. 이는 solve의 기존 완전입력 요구와 맞춘 의도된 강화다.
- Decimal 변환·산술 실패는 구조화된 valid=False/errors로 반환한다. 반환할 cost/time/terminal이 비유한이면 거부한다. NaN과 tolerance를 비교해 통과시키지 않는다.
- ledger의 재고·비용·시간 공식, 초기/도착 reserve 인덱스,1e-7t/1e-6h tolerance와 solver 코드는 변경하지 않았다. 이것은 전체 스키마/정밀도/단위 계약 재구현이 아니다.

## 실행 증거

- 새 direct-ledger 회귀187개: 원본60통과/56실패/71예외 → 후보187통과.
- reserve/deadline 현재 동작을 고정하는 characterization8개: 원본·후보 모두 통과. 특히 마감26.32−5e-7h에서 solver INFEASIBLE/ledger valid라는 기존 차이를 변경하지 않았다.
- 동결 합성28개: 원본·후보 모두 통과하고 상태/비용/시간 결과 동일.
- Linux Python3.12.14, NumPy2.3.5, SciPy1.17.0. 설치 없이 stdlib unittest 사용. 원본65 pytest나 전체834는 재실행하지 않았다.187/8/28을 기존834에 더하지 않는다.
- 별도 코드 검토에서 첫 후보의 dictionary-key/value 검증 우회가 발견돼 수정했고 mapping9개 회귀를 추가했다. 배포 전 후보 검토에서 발견한 문제이며 원본은 그대로 보존했다.

## 재현

기존 보존 원본에서 source/research/cost_time_integration, procurement 의존성, 원본 port_call_time/model.py를 조합한 별도 검증 트리를 사용한다. import할 research 패키지 루트를 PYTHONPATH로 지정한다. 새설치·repo변경 불필요.

    PYTHONPATH=<base-root> python tests/test_ledger_case_validation.py
    PYTHONPATH=<candidate-root> python tests/test_ledger_case_validation.py
    PYTHONPATH=<base-root> python tests/test_boundary_characterization.py
    PYTHONPATH=<candidate-root> python tests/test_boundary_characterization.py
    PYTHONPATH=<base-root> python tests/replay_frozen_cases.py
    PYTHONPATH=<candidate-root> python tests/replay_frozen_cases.py

patch의 대상은 research/cost_time_integration/ledger.py와 신규시험2개다. candidate/ledger.py는 검토용 완성파일이다. base/ledger.py는 변경 전 동일바이트 파일이다. 파일 경로만 마스킹한 로그와 원본·후보 해시는evidence/ 및 PROVENANCE_AND_RESULTS.json에 있다.

## 외부 재검토 질문

1. numeric NaN/Inf/bool/string 및 malformed vector가 어떤 직접 호출에서도 valid=True를 우회할 수 있는가?
2. Decimal traps on/off, 출력 float overflow, numpy scalar/array 호환에서 예외 누출 또는 false success가 남는가?
3. 원장 공식·reserve 정책·deadline 허용오차가 원본 그대로인가? 신규 guard의 정상 입력 거부 부작용은 무엇인가?
4. 신규시험187/경계8/동결28의 주장과 실제 코드·로그가 일치하는가? 변경부분만 검토하고 전체834/배포승인으로 확대하지 말 것.

적용·배포 전 검토 후보이며, 실선 절감·현장 안전성 또는 운영 수정 완료를 의미하지 않는다.

## 별도 최종 검토

이전 후보 ledger SHA417b5bf96c9eae6dea0e3210a1cea3065740f450fbb1e938665fd1e605e207fd에 대해 별도 검토자가175회귀+8경계를 재실행해 모두 통과했고3개 dictionary 반례를 거부함을 확인했다. AST 비교로 기존 원장 계산이 함수명 외 동일함을 확인했다. 이후 overflow/trap/quantity6개 시험만 추가했고 구현자 실행은187개 모두 통과했다. 코드 변경 없이 시험만 추가했다. 외부 Claude/Jules 변경분 재검토는 아직 남았다.
