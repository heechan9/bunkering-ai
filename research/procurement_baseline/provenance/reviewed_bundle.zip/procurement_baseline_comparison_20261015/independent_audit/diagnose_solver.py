import sys,json
from pathlib import Path
P=Path('/workspace/shared/procurement_baseline_comparison_20261015')
sys.path.insert(0,str(P/'vendor'))
import procurement as m
c=m.Case(**next(x['case'] for x in json.load(open(P/'cases.json')) if x['case']['case_id']=='monetary_fees_010'))
original=m.milp
for presolve in [True,False]:
 calls=[]
 def wrapped(*args,**kw):
  kw['options']={**kw.get('options',{}),'presolve':presolve}
  r=original(*args,**kw)
  calls.append(dict(status=r.status,message=r.message,fun=r.fun,x=r.x.tolist() if r.x is not None else None))
  return r
 m.milp=wrapped
 print(json.dumps(dict(presolve=presolve,result=m.solve(c),calls=calls),default=float))
