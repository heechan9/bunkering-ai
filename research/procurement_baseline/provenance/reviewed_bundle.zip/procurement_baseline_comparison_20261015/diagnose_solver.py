"""Reproduce original failure and record which MILP phase returned it."""
import importlib.util,json
from pathlib import Path
R=Path(__file__).resolve().parent
c=next(x['case'] for x in json.loads((R/'cases.json').read_text()) if x['case']['case_id']=='monetary_fees_010')
out={}
for name in ['vendor','patched']:
    spec=importlib.util.spec_from_file_location(name,R/name/'procurement.py');m=importlib.util.module_from_spec(spec)
    import sys;sys.modules[name]=m;spec.loader.exec_module(m)
    real=m.milp;trace=[]
    def traced(*args,**kwargs):
        r=real(*args,**kwargs);trace.append(dict(call_index=len(trace)+1,options=kwargs.get('options'),status=int(r.status),message=r.message,objective=r.fun));return r
    m.milp=traced
    out[name]=dict(result=m.solve(m.Case(**c)),milp_calls=trace)
(R/'solver_diagnostic.json').write_text(json.dumps(out,indent=2))
