import sys,unittest
from pathlib import Path
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'patched'))
import procurement
print('Regression suite module:',procurement.__file__)
s=unittest.TestLoader().discover(str(R/'vendor'),pattern='test_procurement.py')
r=unittest.TextTestRunner(verbosity=2).run(s)
sys.exit(not r.wasSuccessful())
